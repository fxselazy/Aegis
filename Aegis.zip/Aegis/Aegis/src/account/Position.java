// ผู้รับผิดชอบ 62130500046 นาย ภูสิทธิ อัศวธีระเกียรติ์
package account;

public enum Position {
    DEPARTMENT, STUDENT

}
