// ผู้รับผิดชอบ 62130500046 นาย ภูสิทธิ อัศวธีระเกียรติ์
package policy;

public interface Policy {

    public static final int MAX_COURSES = 7;
    public static final int MIN_COURSES = 3;
}
